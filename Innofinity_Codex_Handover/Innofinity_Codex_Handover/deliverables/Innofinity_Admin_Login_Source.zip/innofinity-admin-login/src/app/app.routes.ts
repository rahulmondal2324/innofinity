import { Routes } from "@angular/router";
import { adminGuard, guestGuard } from "./core/auth/auth.guards";

export const routes: Routes = [
  {
    path: "auth/login",
    title: "Sign in | Innofinity Worldwide",
    canActivate: [guestGuard],
    loadComponent: () =>
      import("./features/auth/pages/login/login").then((m) => m.Login),
  },
  {
    path: "",
    canMatch: [adminGuard],
    loadComponent: () =>
      import("./layout/admin-shell/admin-shell").then((m) => m.AdminShell),
    children: [
      { path: "", pathMatch: "full", redirectTo: "dashboard" },
      {
        path: "dashboard",
        title: "Dashboard | Innofinity Worldwide",
        loadComponent: () =>
          import("./features/dashboard/dashboard").then((m) => m.Dashboard),
      },
    ],
  },
  { path: "**", redirectTo: "auth/login" },
];
