import { ChangeDetectionStrategy, Component, inject } from "@angular/core";
import { SessionStore } from "../../core/auth/session.store";

@Component({
  selector: "iw-admin-dashboard",
  template: `<span class="badge text-bg-light border mb-3"
      >ADMIN WORKSPACE</span
    >
    <h1 class="h2">Welcome, {{ session.user()?.firstName }}</h1>
    <p class="text-secondary">Your administrator session is active.</p>
    <section class="card border-0 shadow-sm mt-4">
      <div class="card-body p-4">
        <h2 class="h5">Your dashboard starts here</h2>
        <p class="text-secondary mb-0">
          Catalogue, order and customer modules will be connected as their APIs
          become available.
        </p>
      </div>
    </section>`,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Dashboard {
  readonly session = inject(SessionStore);
}
