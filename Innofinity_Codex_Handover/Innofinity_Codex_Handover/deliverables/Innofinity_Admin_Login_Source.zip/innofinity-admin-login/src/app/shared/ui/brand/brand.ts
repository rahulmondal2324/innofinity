import { ChangeDetectionStrategy, Component, signal } from "@angular/core";

@Component({
  selector: "iw-admin-brand",
  template: `
    <span class="brand-mark">
      @if (!imageFailed()) {
        <img
          src="/branding/innofinitylogo.png"
          width="58"
          height="58"
          alt="Innofinity Worldwide logo"
          (error)="imageFailed.set(true)"
        />
      } @else {
        <span aria-hidden="true">iw</span>
      }
    </span>
    <span class="brand-name">INNOFINITY<span>WORLDWIDE</span></span>
  `,
  styles: `
    :host {
      display: inline-flex;
      align-items: center;
      gap: 13px;
    }
    .brand-mark {
      display: grid;
      place-items: center;
      width: 58px;
      height: 58px;
      border-radius: 12px;
      background: #111329;
      overflow: hidden;
    }
    .brand-mark img {
      object-fit: contain;
    }
    .brand-mark > span {
      color: #64c8df;
      font-size: 28px;
      font-weight: 700;
    }
    .brand-name {
      font-size: 15px;
      font-weight: 750;
      letter-spacing: 2px;
      line-height: 1.5;
    }
    .brand-name > span {
      display: block;
      font-size: 9px;
      font-weight: 500;
      letter-spacing: 4px;
      opacity: 0.66;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Brand {
  protected readonly imageFailed = signal(false);
}
