import { ChangeDetectionStrategy, Component, inject } from "@angular/core";
import { RouterLink, RouterOutlet } from "@angular/router";
import { AuthService } from "../../core/auth/auth.service";
import { SessionStore } from "../../core/auth/session.store";
import { Brand } from "../../shared/ui/brand/brand";

@Component({
  selector: "iw-admin-shell",
  imports: [RouterLink, RouterOutlet, Brand],
  template: `
    <header class="workspace-header">
      <a routerLink="/dashboard" aria-label="Innofinity dashboard"
        ><iw-admin-brand /></a
      ><button
        class="btn btn-outline-secondary btn-sm"
        type="button"
        (click)="auth.logout()"
      >
        <i class="bi bi-box-arrow-right me-2" aria-hidden="true"></i>Sign out
      </button>
    </header>
    <main class="container py-5"><router-outlet /></main>
  `,
  styles: `
    .workspace-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
      padding: 18px 5%;
      border-bottom: 1px solid #e1e8ef;
      background: #fff;
    }
    .workspace-header a {
      color: #14283e;
      text-decoration: none;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminShell {
  readonly auth = inject(AuthService);
  readonly session = inject(SessionStore);
}
